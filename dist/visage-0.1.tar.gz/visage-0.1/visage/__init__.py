"""
Created on Mon Sep 04 13:01:31 2017
@author: Hriddhi Dey
"""

from visage.apply_makeup import ApplyMakeup
from visage.detect_features import DetectLandmarks
